export const API_CONFIG = {
  BASE_URL: 'https://bsky.social',
  CREDENTIALS: {
    identifier: 'futurology.fyi',
    password: '2ijq-dwk2-fhfh-ut3h'
  },
  RATE_LIMITS: {
    MIN_INTERVAL: 3000,
    MAX_RETRIES: 5,
    BASE_DELAY: 10000,
    MAX_DELAY: 60000,
    MAX_REQUESTS: 25,
    WINDOW_DURATION: 60000
  }
};