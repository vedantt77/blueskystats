export const featuredProfiles = [
  {
    handle: 'vedantk.bsky.social',
    credentials: {
      identifier: 'futurology.fyi',
      password: '2ijq-dwk2-fhfh-ut3h'
    }
  },
 
];